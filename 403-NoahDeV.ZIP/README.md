######################
#403 | By: Noah | DeV#
######################


###

root@Your-Host:~# Du darfst diese Seite leider nicht aufrufen.|

###

COLOR CHANGE

Go to an .html file and add: color: #HEX CODE HERE;

###

USAGE

Drop the File on you Web Server and start the Server, you must have an index.html File to use the 403 Page.

###

COPYRIGHT

© 2020 Ungenickt.DE - Noah | DeV

###

CONTACT

Contact me over:

Insta: ungenicktde

Twitter: ungenickt_de

Discord: Noah | DeV#3096